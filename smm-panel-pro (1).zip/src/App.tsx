/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import axios from "axios";
import { doc, getDoc } from "firebase/firestore";
import { db } from "./lib/firebase";
import Layout from "./components/Layout";
import Home from "./pages/Home";
import Courses from "./pages/Courses";
import Dashboard from "./pages/Dashboard";
import Profile from "./pages/Profile";
import Admin from "./pages/Admin";
import Login from "./pages/Login";

export default function App() {
  useEffect(() => {
    const resolveBackendUrl = async () => {
      try {
        // Fallback: Default to current origin if in Cloud Run or Localhost
        const origin = window.location.origin;
        if (origin.includes(".run.app") || origin.includes("localhost") || origin.includes("127.0.0.1")) {
          axios.defaults.baseURL = origin;
          console.log(`[API] Initial fallback baseURL set to origin: ${origin}`);
        } else {
          // Absolute fallback to active Cloud Run server for custom domain (pyaresmmpanel.online)
          const activeBackendUrl = "https://ais-pre-n2umeaxvo6qnc7chsbm27z-523409699457.asia-southeast1.run.app";
          axios.defaults.baseURL = activeBackendUrl;
          console.log(`[API] Custom domain detected. Falling back to active Backend: ${activeBackendUrl}`);
        }
        
        // Load dynamically from settings document in Firestore
        const settingsSnap = await getDoc(doc(db, "settings", "payment"));
        if (settingsSnap.exists()) {
          const sData = settingsSnap.data();
          if (sData && sData.backendApiUrl) {
            const savedUrl = sData.backendApiUrl.trim();
            if (savedUrl) {
              // Ensure it starts with http
              const finalUrl = savedUrl.startsWith("http") ? savedUrl : `https://${savedUrl}`;
              axios.defaults.baseURL = finalUrl;
              console.log(`[API] Base URL configured to saved custom backend: ${finalUrl}`);
            }
          }
        }
      } catch (err) {
        console.error("[API] Dynamic backend resolution failed:", err);
      }
    };
    resolveBackendUrl();
  }, []);

  return (
    <Router>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Courses />} />
          <Route path="courses" element={<Courses />} />
          <Route path="dashboard" element={<Dashboard />} />
          <Route path="profile" element={<Profile />} />
          <Route path="admin" element={<Admin />} />
          <Route path="login" element={<Login />} />
        </Route>
      </Routes>
    </Router>
  );
}


