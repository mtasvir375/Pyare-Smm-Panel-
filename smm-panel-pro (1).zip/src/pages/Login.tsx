import { useState } from "react";
import { motion } from "motion/react";
import { Lock, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { loginWithGoogle } from "@/lib/firebase";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";

export default function Login() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);

  const handleGoogleLogin = async () => {
    setIsLoading(true);
    try {
      await loginWithGoogle();
      toast.success("आसानी से गूगल लॉगिन हो गया!");
      navigate("/");
    } catch (error: any) {
      console.error("Google login error:", error);
      if (error?.code === "auth/unauthorized-domain" || String(error).includes("unauthorized-domain")) {
        toast.error("यह custom domain (pyaresmmpanel.online) Firebase Console में Authorized नहीं है।", {
          description: "कृपया Firebase Console -> Authentication -> Settings -> Authorized Domains में 'pyaresmmpanel.online' को जोड़ें।",
          duration: 12000
        });
      } else if (error?.code === "auth/popup-blocked" || error?.code === "auth/cancelled-popup-request") {
        toast.error("Google Pop-up Block हो गया।", {
          description: "कृपया अपने ब्राउज़र में pop-ups को allow करें ताकि Google login popup खुल सके।",
          duration: 8000
        });
      } else {
        toast.error("Failed to sign in with Google: " + (error?.message || error));
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center p-4 bg-gray-50/50">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.3 }}
        className="w-full max-w-md my-8"
        id="login-container"
      >
        <Card className="border-none shadow-[0_20px_50px_rgba(0,0,0,0.08)] rounded-[2.5rem] overflow-hidden bg-white">
          <CardHeader className="space-y-4 text-center pb-6 pt-10 px-8">
            <div className="mx-auto w-16 h-16 bg-primary/10 rounded-[1.5rem] flex items-center justify-center mb-1">
              <Lock className="w-8 h-8 text-primary" />
            </div>
            <div className="space-y-2">
              <CardTitle className="text-3xl font-black tracking-tight text-gray-900">
                Welcome Back
              </CardTitle>
              <CardDescription className="text-gray-500 text-sm font-medium px-4">
                Sign in to manage your social media growth and services
              </CardDescription>
            </div>
          </CardHeader>

          <CardContent className="p-8 pt-0 space-y-6">
            <div className="space-y-4 py-2">
              <Button 
                id="google-login-btn"
                variant="outline" 
                type="button"
                className="w-full h-14 rounded-2xl border-2 border-gray-150 hover:border-primary/20 hover:bg-primary/5 transition-all duration-300 flex items-center justify-center gap-3 group shadow-sm active:scale-95"
                onClick={handleGoogleLogin}
                disabled={isLoading}
              >
                {isLoading ? (
                  <Loader2 className="w-6 h-6 animate-spin text-primary" />
                ) : (
                  <svg className="w-6 h-6" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                    />
                  </svg>
                )}
                <span className="text-base font-bold text-gray-700 group-hover:text-primary transition-colors">
                  {isLoading ? "Connecting Google..." : "Continue with Google"}
                </span>
              </Button>
            </div>

            <p className="text-center text-[11px] text-gray-400 font-medium px-4">
              By continuing, you agree to our Terms of Service and Privacy Policy. All logins are safely routed through secure SSL.
            </p>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
